# Mythic Weapons Texture Pack (combined)

This is the "Mythic Weapons Texture Pack" you sent, with the Stormcaller bow
texture pack merged in — every file from both packs lives under one
`assets/` folder now, with one `pack.mcmeta`. No file paths collided between
the two, so nothing was overwritten or dropped; this is a straight union.

## Two different systems live in this one pack

That matters because they have different requirements — read this before
assuming "install the pack" is the whole story.

### 1. Vanilla item-model reskins (no mods needed)

Everything under `assets/minecraft/items/*.json`, `assets/dragonelytra/`,
and — as of this update — `assets/custombow/` (the Stormcaller bow) uses
the modern vanilla item-model system. This works on a completely plain
1.21.11 client — no OptiFine, no Fabric, no mods. Any player who has the
resource pack loaded sees these:

| Vanilla item | CustomModelData | Becomes |
|---|---|---|
| Diamond Sword | 1 | Moonlight Refractor |
| Netherite Sword | 1 | Moonlight Refractor |
| Netherite Sword | 2 | Crimson Moon's Semblance |
| Netherite Axe | 1 | Mythic Axe |
| Netherite Pickaxe | 1 | Mythic Pickaxe |
| Mace | 1 | God Mace |
| Trident | 1 | Mythic Trident |
| Blaze Rod | 1 | Custom Staff |
| Blaze Rod | 2 | Custom Staff v2 |
| Apple | 1 | Netherite Apple |

The `dragonelytra:dragon_elytra` model is also in here (item-model JSON,
3D model, texture, and an equipment/wings layer for the worn-on-back look),
but it's **inert** right now — nothing gives an item that points at it. It's
built the same way our Stormcaller bow is: a plugin would need to give an
elytra and call `meta.setItemModel(new NamespacedKey("dragonelytra",
"dragon_elytra"))` for it to ever show up. Say the word if you want a
plugin item built for it.

None of these CustomModelData values touch bows, so there's zero collision
with the Stormcaller bow's own CustomModelData `1` on `minecraft:bow` — the
range-dispatch system is scoped per vanilla item type.

**The Stormcaller bow** (`assets/custombow/`) is matched a different way
than the sword/axe/etc. reskins above: instead of `custom_model_data`, the
plugin sets a proper `minecraft:item_model` component (`custombow:stormcaller`)
directly on the item, and `assets/custombow/items/stormcaller.json` is the
item-model definition that switches between standby / pulling-back-partway
/ fully-drawn art depending on how far the bow is charged — same mechanism
vanilla's own bow uses. **This was the bug you just hit**: the plugin's
config already pointed at `custombow:stormcaller`, but earlier deliveries
of this pack never actually contained that namespace — so the client had
an item asking for a model that didn't exist anywhere, which is exactly
what the purple/black checkered pattern means. It's fixed now; the four
Amos' Bow model files (from the original CIT pack) and their textures were
converted into this vanilla item-model format and added in.

### 2. OptiFine/CIT extras (needs CIT Resewn Continuation)

A few purely cosmetic extras in this pack only show up for players running
**CIT Resewn Continuation** (Fabric, or beta NeoForge) — everyone else just
doesn't see these, nothing breaks without them:

- `emissive.properties` (`suffix.emissive=_e`) — any texture in the pack
  with an `_e` suffix (several of the weapon textures have one) gets treated
  as a glowmap. Cosmetic-only; the base textures still show without it.
- `color.properties` (`lilypad=3c8207`) — a lilypad recolor, unrelated to
  weapons, carried over from the original pack.
- `assets/minecraft/optifine/cem/trident.jem` — a Custom Entity Model for
  the trident's third-person/dropped-item look. Without the mod, the
  trident still shows the reskinned texture from system #1 above, just with
  the plain vanilla trident shape instead of this enhanced model.
- `assets/minecraft/optifine/cit/bow/amos_bow/` — the original CIT-matched
  copy of the bow reskin, left in as a harmless leftover. It's redundant
  now that the bow has a real vanilla item-model (system #1 above covers
  every player); this only still matters if you're specifically running
  CIT Resewn for some other reason.

So: every weapon reskin, including the bow, now works for everyone with no
mods required. The emissive glow, lilypad recolor, and trident's enhanced
third-person model remain CIT-only cosmetic bonuses.

## What I changed while merging

- `pack.mcmeta`: unified into one file, `pack_format` set to **75** (the
  weapons pack was previously on `55`, which is 1.21.5; the bow pack's own
  `pack.mcmeta` was already on 75). Description now mentions both.
- `pack.png`: kept the weapons pack's icon (the bow pack didn't ship one).
- Added `assets/custombow/` (item-model definition, 4 stage models, and
  their textures) — converted from the bow pack's original CIT-only files
  so the bow reskin also works without any client mod. This is the fix for
  the missing-texture bow.

## What I verified vs. didn't

Same caveat as before: no Minecraft client here to actually load this and
look at it. What I did check, mechanically:

- Every JSON and `.jem` file in both source packs parses without error (22
  in the weapons pack, plus the bow pack's own, checked earlier).
- Every PNG in both source packs opens as a valid, uncorrupted image (48 in
  the weapons pack).
- Every model reference in every `items/*.json` file resolves to an actual
  model file present in the pack — nothing points at a missing custom model.
- Every texture reference in every model file resolves to an actual PNG in
  the pack, with the one expected exception of two "particle" textures that
  intentionally fall back to vanilla's own built-in trident icon (normal
  resource-pack behavior, not a bug).
- No file path collided between the two source packs, so the merge is a
  clean union with nothing overwritten.

Not verified (same open items as the standalone bow pack): whether CIT Resewn
Continuation's NBT-style CustomModelData matcher reads back correctly
against Paper 1.21.11's actual runtime item data, and whether the plugin
itself compiles (this sandbox can't reach Maven Central). Please test on a
real server + client when you get the chance.

## Credit

- Weapon reskins (Moonlight Refractor, Crimson Moon's Semblance, Mythic
  Axe, Mythic Pickaxe, God Mace, Mythic Trident, Custom Staff, Dragon
  Elytra): from the Mythic Weapons Texture Pack you provided.
- Stormcaller bow (Amos' Bow): from Teyvat Weapon Collection by Raycifer,
  extracted and repointed at the plugin's custom bow.
- Netherite Apple: the 16x16 apple texture you provided, wired in below.

## Netherite Apple addition

Merged in the standalone "Netherite Apple" texture you sent (just a single
16x16 `apple.png`, no model/pack files of its own) using the same
CustomModelData system as the sword/axe/etc. reskins above:

- `assets/minecraft/textures/item/netherite_apple.png` — your texture, copied
  in as-is.
- `assets/minecraft/models/item/netherite_apple.json` — a standard flat
  item model (`minecraft:item/generated` + `layer0`) pointing at it.
- `assets/minecraft/items/apple.json` — new item-model override for vanilla
  `APPLE`: CustomModelData `1` shows `item/netherite_apple`, anything else
  (including no CustomModelData at all) falls back to the plain vanilla
  apple. This means normal apples anyone else is holding are completely
  unaffected.

This works the same no-mods-needed way as the other reskins in table 1
above — any player with the pack loaded sees it, no OptiFine/CIT needed.
The NetheriteHealing plugin's `apple` item now sets `custom-model-data: 1`
in its own `config.yml` to match this override exactly; if you ever renumber
the threshold here, update that config value (and reload) to match.

No Netherite Carrot texture yet — `carrot.json` intentionally doesn't exist
in this pack, so real and custom carrots both still render as the plain
vanilla carrot for now. Send the carrot texture whenever you find one and
I'll wire it in the same way.
